<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Calisma extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "calisma_v";
        $this->load->model('Calisma_model');
    }

    public function index()
    {
        $viewData = new stdClass();

        /** Tablodan Verilerin Getirilmesi.. */
        $items= $this->Calisma_model->get_all();

        /** View'e gönderilecek Değişkenlerin Set Edilmesi.. */

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }
    /*
    public function yeni_departman_kaydet(){
        $insert = $this->departmanlar_model->departman_kaydet(
            array(
                "departma_adi" => $this->input->post('ad'),
                "bolum" => $this->input->post('soyad'),
                "ad" => $this->input->post('telefon'),
                "soyad" => $this->input->post('mail')
            )
        );
        if($insert){
            $msg = "Başarılı";
        }
        $this->session->set_flashdata('msg',$msg);
        redirect(base_url('adaylar'));
    }
    */
}