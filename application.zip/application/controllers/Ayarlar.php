<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ayarlar extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "ayarlar_v";
        $this->load->model('ayarlar_model');
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->ayarlar = $this->ayarlar_model->ayarlar();

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }
    public function ayarlar_kaydet(){
        $insert = $this->ayarlar_model->ayarlar_kaydet(
            array(
                "departma_adi" => $this->input->post('departman_adi'),
                "bolum" => $this->input->post('bolum'),
                "ad" => $this->input->post('ad'),
                "soyad" => $this->input->post('soyad')
            )
        );
        if($insert){
            $msg = "Başarılı";
        }
        $this->session->set_flashdata('msg',$msg);
        redirect(base_url('departmanlar'));
    }
}
