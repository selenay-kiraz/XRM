<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Personeller extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "personeller_v";
        $this->load->model('personeller_model');
    }

    public function index()
    {
        $viewData = new stdClass();
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->personeller = $this->personeller_model->personeller();

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function yeni_ekle(){
        $viewData = new stdClass();
        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "add";

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function yeni_personel_kaydet(){
        $insert = $this->personeller_model->personel_kaydet(
           array(
               "ad" => $this->input->post('ad'),
               "soyad" => $this->input->post('soyad'),
               "dogum_tarihi" => $this->input->post('dogum_tarihi'),
               "cinsiyet" => $this->input->post('cinsiyet'),
               "medeni_hal" => $this->input->post('medeni_hal'),
               "uyruk" => $this->input->post('uyruk'),
               "kimlik_no" => $this->input->post('kimlik_no'),
               "adres" => $this->input->post('adres'),
               "ulke" => $this->input->post('ulke'),
               "sehir" => $this->input->post('sehir'),
               "telefon" => $this->input->post('telefon'),
               "mail" => $this->input->post('mail')
           )
        );
        if($insert){
            $msg = "Başarılı";
        }else{
            $msg = "Başarısız";
        }
        $this->session->set_flashdata('msg',$msg);
        redirect(base_url('personeller'));
    }
}
