<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-6"><h4>Personeller</h4></div>
                    <div class="col-sm-6"><a class="btn btn-sm btn-success pull-right" href="personeller/yeni_ekle"><i class="fa fa-plus"></i> Yeni Ekle</a> </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12">
                        <table class="table table-responsive table-hover">
                            <thead>
                                <th>Ad Soyad</th>
                                <th>Kimlik No</th>
                                <th>Mail</th>
                                <th>Düzenle</th>
                            </thead>
                            <tbody>
                            <?php
                            foreach ($personeller as $personel){
                                ?>
                                <tr>
                                    <td><?php echo $personel->ad; ?></td>
                                    <td><?php echo $personel->soyad; ?></td>
                                    <td><?php echo $personel->mail; ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-danger" href="#">Sil</a>
                                        <a class="btn btn-sm btn-info" href="#">Düzenle</a>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>