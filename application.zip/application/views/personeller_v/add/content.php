
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-sm-6"><h4>Personeller</h4></div>
                </div>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo base_url('personeller/yeni_personel_kaydet'); ?>">
                    <div class="row form-group" style="margin-top:30px; margin-bottom:30px;">
                        <div class="col-sm-3">
                            <label>Ad</label>
                            <input type="text" class="form-control" name="ad">
                        </div>
                        <div class="col-sm-3">
                            <label>Soyad</label>
                            <input type="text" class="form-control" name="soyad">
                        </div>
                        <div class="col-sm-3">
                            <label>Doğum Tarihi</label>
                            <input type="text" class="form-control" name="dogum_tarihi">
                        </div>
                        <div class="col-sm-3">
                            <label>Cinsiyet</label>
                            <input type="text" class="form-control" name="cinsiyet">
                        </div>
                    </div>
                    <div class="row form-group" style="margin-top:30px; margin-bottom:30px;">
                        <div class="col-sm-3">
                            <label>Medeni Hal</label>
                            <input type="text" class="form-control" name="medeni_hal">
                        </div>
                        <div class="col-sm-3">
                            <label>Uyruk</label>
                            <input type="text" class="form-control" name="uyruk">
                        </div>
                        <div class="col-sm-3">
                            <label>Kimlik No</label>
                            <input type="text" class="form-control" name="kimlik_no">
                        </div>
                        <div class="col-sm-3">
                            <label>Adres</label>
                            <input type="text" class="form-control" name="adres">
                        </div>
                    </div>
                    <div class="row form-group" style="margin-top:30px; margin-bottom:30px;">
                        <div class="col-sm-3">
                            <label>Ulke</label>
                            <input type="text" class="form-control" name="ulke">
                        </div>
                        <div class="col-sm-3">
                            <label>Sehir</label>
                            <input type="text" class="form-control" name="sehir">
                        </div>
                        <div class="col-sm-3">
                            <label>Telefon</label>
                            <input type="text" class="form-control" name="telefon">
                        </div>
                        <div class="col-sm-3">
                            <label>Mail</label>
                            <input type="text" class="form-control" name="mail">
                        </div>
                    </div>
                    <div class="row form-group" style="margin-top:30px; margin-bottom:30px;">
                        <div class="col-sm-12"><button type="submit" class="btn btn-sm btn-success pull-right"><i class="fa fa-plus"></i> Oluştur</button> </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>