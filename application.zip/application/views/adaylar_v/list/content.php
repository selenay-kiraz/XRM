<div class="row">
    <div class="col-sm-12">
        <h4 class="m-b-lg">
            Adaylar
        </h4>

        <div class="col-sm-12">
            <div class="widget p-lg">

                <?php if(empty($items)) { ?>


                <?php } else {?>

                    <table class="table table-responsive table-hover">
                        <thead>
                        <th>Ad</th>
                        <th>Soyad</th>
                        <th>Telefon</th>
                        <th>E Mail</th>
                        </thead>

                        <tbody>

                        <?php foreach ($items as $item){?>
                            <tr>
                                <td><?php echo $item->ad; ?></td>
                                <td><?php echo $item->soyad; ?></td>
                                <td><?php echo $item->telefon; ?></td>
                                <td><?php echo $item->mail; ?></td>
                            </tr>
                        <?php } ?>


                        </tbody>
                    </table>
                <?php }?>



            </div>
        </div>
    </div>