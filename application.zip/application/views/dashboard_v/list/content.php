<div class="container" style="padding-bottom: 5vh; padding-right: 5vw;">
    <div class="col-sm-12" style="padding-top:3vh;">
        <div class="col-sm-7">
            <img src="<?php echo base_url("assets"); ?>/assets/images/career.jpg" style="border-radius: 10px;">
        </div>
        <div class="col-sm-5 text-center" style="padding-top: 20vh;">
            <p style="font-size:50px;">Kariyer</p>
        </div>
    </div>
    <div class="col-sm-12" style="padding-top: 45px;">
        <div class="col-sm-5 text-center" style="padding-top: 20vh;">
            <p style="font-size:50px;">Gelecek</p>
        </div>
        <div class="col-sm-7">
            <img src="<?php echo base_url("assets"); ?>/assets/images/future.jpg" style="border-radius: 10px;">
        </div>
    </div>
    <div class="col-sm-12" style="padding-top: 45px;">
        <div class="col-sm-7">
            <img src="<?php echo base_url("assets"); ?>/assets/images/equipage.jpg" style="border-radius: 10px;">
        </div>
        <div class="col-sm-5 text-center" style="padding-top: 20vh;">
            <p style="font-size:50px;">Donanım</p>
        </div>
    </div>
</div>