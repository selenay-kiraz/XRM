<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Etkinlikler
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget p-lg">

            <div class="alert alert-info text-center">
                <p>Yeni bir etkinlik bulunmamaktadır! <a href="#"></a></p>
            </div>

            <table class="table table-hover table-striped">
                <thead>
                <th>Etkinlik Adı</th>
                <th>Tarihi</th>
                <th>Açıklama</th>
                <th>Hakkında</th>
                <th>Durumu</th>
                </thead>
                <tbody>
                <tr>
                    <td>XRM Eğitimleri</td>
                    <td>22/05/2020</td>
                    <td>XRM Hakkında Yeni Bilgiler</td>
                    <td>Kendinizi geliştirebileceğiniz bir eğitim</td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>

                    <?php /** <td>
                        <a href="#" class="btn btn-sm btn-danger btn-outline"><i class="fa fa-trash"></i> Sil</a>
                        <a href="#" class="btn btn-sm btn-info btn-outline"><i class="fa fa-pencil-square-o"></i> Düzenle</a>
                    </td> */ ?>
                </tr>
                <tr>
                    <td>Oryantasyon</td>
                    <td>05/07/2020</td>
                    <td>Şirketimizi Tanıyalım</td>
                    <td>Şirketimizin işleyişi ve ilerleyişi ile ilgili bilmeniz gerekenler </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Sunum Zamanı</td>
                    <td>08/11/2020 </td>
                    <td>Yeni Proje Sunumu</td>
                    <td>Onaylanan projeler için yapılacak sunumlar </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Covid-19 </td>
                    <td>Covid-19 Bitimi </td>
                    <td>Covid-19 Kurtuluşu</td>
                    <td>Bitiş Partisi yapılacak :) </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Bahar Şenliği</td>
                    <td>15/05/2020 </td>
                    <td>Geleneksel Bahar'a Hoşgeldin Karşılaması</td>
                    <td> Şirket çalışanlarımızla Hoşgeldin Bahar temalı bahar şenlikleri </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Hoşgeldin </td>
                    <td>09/06/2020 </td>
                    <td>Yeni Adaylarımıza Hoşgeldin diyoruz!</td>
                    <td> Aday seçimlerinin sonunda kabul görülen adaylarımıza hoşgeldin partisi düzenliyoruz! </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Ekip Pikniklerimiz</td>
                    <td>11/06/2020 </td>
                    <td>Şirket Etkinliği</td>
                    <td>Şirketimiz ile beraber kaynaşma pikniğimizin tarihi yaklaşıyor! Kimselere sakın söz vermeyin. :)</td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Sunum Zamanı</td>
                    <td>22/06/2020 </td>
                    <td>Proje Sunumu</td>
                    <td>Sunumların değerlendirilmesi yapılacak </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>
                <tr>
                    <td>Anneler Günü</td>
                    <td>08/05/2020 </td>
                    <td> Annelerimizin anneler gününü kutlarız!</td>
                    <td> :) </td>
                    <td>
                        <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                    </td>
                </tr>

                </tbody>

            </table>

        </div><!-- .widget -->
    </div><!-- END column -->
</div>
<?php
 /** <a href="#" class="btn btn-outline btn-primary btn-xs pull-right"> <i class="fa fa-plus"></i> Yeni Ekle</a> */ ?>