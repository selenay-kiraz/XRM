<div class="row">
    <div class="col-sm-12">
        <h4 class="m-b-lg">
            Eğitimler
        </h4>

        <div class="col-sm-12">
            <div class="widget p-lg">

                <?php if(empty($items)) { ?>
                    <div class="alert alert-info text-center">
                        <p>Eğitimlerimiz hakkındaki detaylı bilgi için Aday Temsilcimiz ile görüşünüz! :) </p>
                    </div>

                <?php } else {?>

                    <table class="table table-responsive table-hover">
                        <thead>
                        <th>Eğitim ID</th>
                        <th>Eğitim Adı</th>
                        <th>Eğitim Konusu</th>
                        <th>Eğitim Tarihi</th>
                        </thead>

                        <tbody>
                        <tr>
                            <td>#1062</td>
                            <td>PHP ile Web Desing</td>
                            <td>PHP kullanarak Web tasarımını nasıl yapacağımız hakkında temel bilgiler.</td>
                            <td>2020-05-29</td>
                        </tr>
                        <tr>
                            <td>#4202</td>
                            <td>JavaScript Eğitimi</td>
                            <td>PHP ile JavaScript'i birleştiren eğitim.</td>
                            <td>2020-06-04</td>

                        </tr>
                        <tr>
                            <td>#2311</td>
                            <td>XRM Yazılımları</td>
                            <td>XRM Yazılımlarının alt yapısını tanımak için verilen bir eğitim.</td>
                            <td>2020-06-18</td>

                        </tr>
                        <tr>
                            <td>#1326</td>
                            <td>CSS Eğitimi</td>
                            <td>CSS Nedir? PHP'de Nerelerde işimize yarar temalı bir eğitim.</td>
                            <td>2020-06-19</td>

                        </tr>
                        <tr>
                            <td>#4111</td>
                            <td>HTML Eğitimi</td>
                            <td>HTML Nedir? PHP'de Nerelerde işimize yarar temalı bir eğitim.</td>
                            <td>2020-06-21</td>

                        </tr>
                        <tr>
                            <td>#0011</td>
                            <td>Şirket Yönetim Sistemi</td>
                            <td>Şirket yönetim sisteminin alt yapısını tanıtmak için verilen bir eğitim.</td>
                            <td>2020-06-01</td>

                        </tr>
                        </tbody>
                    </table>
                <?php }?>



            </div>
        </div>
    </div>