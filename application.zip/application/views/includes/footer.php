<div class="wrap p-t-0">
    <footer class="app-footer">
        <div class="clearfix">
            <div class="copyright pull-left">Tüm hakları saklıdır | Selenay Kiraz & Kübra Yeğin <?php echo date("Y"); ?> &copy;</div>
        </div>
    </footer>
</div>
