<aside id="menubar" class="menubar light">
    <div class="app-user">
        <div class="media">
            <div class="media-left">
                <div class="avatar avatar-md avatar-circle">
                    <a href="javascript:void(0)"><img class="img-responsive" src="<?php echo base_url("assets"); ?>/assets/images/221.jpg" alt="avatar"/></a>
                </div><!-- .avatar -->
            </div>
            <div class="media-body">
                <div class="foldable">
                    <h5><a href="javascript:void(0)" class="username">Aday</a></h5>
                    <ul>
                        <li class="dropdown">
                            <a href="hesap/cikisyap" >
                                <small>Çıkış</small>
                            </a>
                        </li>
                    </ul>
                </div>
            </div><!-- .media-body -->
        </div><!-- .media -->
    </div><!-- .app-user -->

    <div class="menubar-scroll">
        <div class="menubar-scroll-inner">
            <ul class="app-menu">


                <li>
                    <a href="dashboard">
                        <i class="menu-icon zmdi zmdi-view-dashboard zmdi-hc-lg"></i>
                        <span class="menu-text">Başlangıç</span>
                    </a>
                </li>

                <li>
                    <a href="duyurular">
                        <i class="menu-icon zmdi zmdi-puzzle-piece zmdi-hc-lg"></i>
                        <span class="menu-text">Duyurular</span>
                    </a>
                </li>

                <li class="has-submenu">
                    <a href="<?php echo base_url("adaylar"); ?>">
                        <i class="menu-icon zmdi zmdi-apps zmdi-hc-lg"></i>
                        <span class="menu-text">Aday Listesi</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("product"); ?>">
                        <i class="menu-icon fa fa-cubes"></i>
                        <span class="menu-text">Etkinlikler</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("personeller"); ?>">
                        <i class="menu-icon zmdi zmdi-layers zmdi-hc-lg"></i>
                        <span class="menu-text">Personeller</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("Departmanlar"); ?>">
                        <i class="menu-icon fa fa-newspaper-o"></i>
                        <span class="menu-text">Departmanlar</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("Egitimler"); ?>">
                        <i class="menu-icon fa fa-calendar"></i>
                        <span class="menu-text">Eğitimler</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("Calisma"); ?>">
                        <i class="menu-icon zmdi zmdi-check zmdi-hc-lg"></i>
                        <span class="menu-text">Çalışma Saatleri</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo base_url("Genel"); ?>">
                        <i class="menu-icon zmdi zmdi-settings zmdi-hc-lg"></i>
                        <span class="menu-text">Genel Ayarlar</span>
                    </a>
                </li>

            </ul><!-- .app-menu -->
        </div><!-- .menubar-scroll-inner -->
    </div><!-- .menubar-scroll -->
</aside>