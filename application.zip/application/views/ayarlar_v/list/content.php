<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Ayarlar
        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget p-lg">

            <div class="alert alert-info text-center">
                <p>Yeni bir etkinlik bulunmamaktadır! <a href="#"></a></p>
            </div>

            <table class="table table-hover table-striped">
                <thead>
                <th>Etkinlik Adı</th>
                <th>Tarihi</th>
                <th>Açıklama</th>
                <th>Hakkında</th>
                <th>Durumu</th>
                </thead>
                <tbody>

                </tbody>

            </table>

        </div><!-- .widget -->
    </div><!-- END column -->
</div>
<?php
/** <a href="#" class="btn btn-outline btn-primary btn-xs pull-right"> <i class="fa fa-plus"></i> Yeni Ekle</a> */ ?>