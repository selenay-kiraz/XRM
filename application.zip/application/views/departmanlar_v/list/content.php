<div class="row">
    <div class="col-sm-12">
        <h4 class="m-b-lg">
            Departmanlar


        </h4>

        <div class="col-sm-12">
            <div class="widget p-lg">

                <?php if(empty($items)) { ?>




                <?php } else {?>

                    <table class="table table-responsive table-hover">
                        <thead>
                        <th>Departman Adı</th>
                        <th>Departman No</th>
                        <th>Sorumlusu</th>
                        <th>E Mail</th>
                        </thead>

                        <tbody>

                        <?php foreach ($items as $item){?>
                            <tr>
                                <td><?php echo $item->departman_adi; ?></td>
                                <td><?php echo $item->departman_no; ?></td>
                                <td><?php echo $item->sorumlusu; ?></td>
                                <td><?php echo $item->email; ?></td>
                                <td>
                                    <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                                </td>
                            </tr>
                        <?php } ?>


                        </tbody>
                    </table>
                <?php }?>



            </div>
        </div>
    </div>