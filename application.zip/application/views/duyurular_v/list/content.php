<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Duyurular


        </h4>
    </div><!-- END column -->
    <div class="col-md-12" >
        <div class="widget p-lg">
            <?php if(empty($items)) { ?>


                <div class="alert alert-info text-center">
                    <p>Burada herhangi yeni bir duyuru bulunmamaktadır! </p>
                </div>

            <?php } else {?>

                <table class="table table-hover table-striped">

                    <thead>
                    <th>Duyuru</th>
                    <th>Departman</th>
                    <th>Açıklama</th>
                    <th>Durum</th>

                    </thead>
                    <tbody>






                    </tbody>

                    <tbody>


                    <?php foreach ($items as $item) { ?>

                        <tr>
                            <td><?php echo $item->duyuru; ?></td>
                            <td><?php echo $item->departman; ?></td>
                            <td><?php echo $item->açıklama; ?></td>
                            <td><?php echo $item->durum; ?></td>

                        </tr>

                    <?php }?>



                    </tbody>

                </table>
            <?php } ?>
        </div><!-- .widget -->
    </div><!-- END column -->




</div>