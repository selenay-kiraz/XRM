
<!--jquery mustafa-->
<link href='css/fullcalendar.css' rel='stylesheet' />
<script src='js/jquery-1.9.1.min.js'></script>
<script src='js/jquery-ui-1.10.2.custom.min.js'></script>
<script src='js/fullcalendar.min.js'></script>

<div class="row">
    <div class="col-sm-12">
        <h4 class="m-b-lg">
            Çalışma Saatleri
        </h4>

        <div class="col-sm-12">
            <div class="widget p-lg">
            <iframe width="100%" height="800px" style="border:0px;" src="http://localhost:8080/xrm/default.php"></iframe>
 
            </div>
        </div>
    </div>
    
<script>

