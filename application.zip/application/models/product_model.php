<?php


class product_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function product_kaydet($data=array()){
        return $this->db->insert('product',$data);
    }
    public function product(){
        return $this->db->get('product')->result();
    }
}