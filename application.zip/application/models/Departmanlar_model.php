<?php


class Departmanlar_model extends CI_Model
{
    public $tableName = "departmanlar";

    public function __construct()
    {
        parent::__construct();
    }


    public function get_all() {

        return $this->db->get($this->tableName)->result();

    }

    /*
    public function departman_kaydet($data=array()){
        return $this->db->insert('departmanlar',$data);
    }
    public function departmanlar(){
        return $this->db->get('Departmanlar')->result();
    }

    */
}