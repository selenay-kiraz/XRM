<?php


class Duyurular_model extends CI_Model
{
    public $tableName = "duyurular";

    public function __construct()
    {
        parent::__construct();
    }

    public function get_all() {

        return $this->db->get($this->tableName)->result();

    }


    /*
    public function Duyuru_kaydet($data=array()){
        return $this->db->insert('Duyurular',$data);
    }
    public function Duyurular(){
        return $this->db->get('Duyurular')->result();
    }
    */
}