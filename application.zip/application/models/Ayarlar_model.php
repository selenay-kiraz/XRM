<?php


class Ayarlar_model extends CI_Model
{

    public $tableName = "Ayarlar";

    public function __construct()
    {
        parent::__construct();
    }
    /*
        public function aday_kaydet($data=array()){
            return $this->db->insert('adaylar',$data);
        }
    */
    public function get_all() {

        return $this->db->get($this->tableName)->result();

    }
}