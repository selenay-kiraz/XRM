<?php


class Personeller_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function personel_kaydet($data=array()){
        return $this->db->insert('personeller',$data);
    }
    public function personeller(){
        return $this->db->get('Personeller')->result();
    }
}